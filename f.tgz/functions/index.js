"use strict";
/* RideMind · Cloud Functions
   Ό,τι αφορά το Pro και τα όρια της Παρέας αποφασίζεται εδώ, στον server, και όχι στο κινητό:
   - proSync:    υπολογίζει Founding Rider / δώρο από τα στοιχεία του λογαριασμού
   - proTrial:   ξεκινά τη δοκιμή μία φορά ανά λογαριασμό, με ώρα server
   - proVerify:  ελέγχει την αγορά απευθείας στο Google Play και τη δένει με έναν μόνο λογαριασμό
   - proVoided:  αφαιρεί το Pro όταν μια αγορά ακυρωθεί ή επιστραφούν τα χρήματα
   - crewCreate / crewJoin: νέα παρέα / είσοδος με κωδικό, με όριο μίας παρέας χωρίς Pro
   Κανένα κλειδί δεν υπάρχει στον κώδικα: η πρόσβαση στο Google Play γίνεται με τον λογαριασμό υπηρεσίας
   που τρέχει τις functions (Application Default Credentials). */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions, logger } = require("firebase-functions/v2");
const admin = require("firebase-admin");
const L = require("./lib");

admin.initializeApp();
const db = admin.firestore();
const FV = admin.firestore.FieldValue;
const TS = admin.firestore.Timestamp;

setGlobalOptions({ region: "europe-west1", maxInstances: 5, memory: "256MiB", timeoutSeconds: 30 });

const PKG = "gr.ridemind.app";
const PRODUCT = "ridemind_pro";
const ADMIN_EMAIL = "tasosktfs@gmail.com";
const FOUNDING_DEFAULT = "2026-11-30";
const CALL = { cors: false, enforceAppCheck: false }; // App Check: θα ενεργοποιηθεί όταν ρυθμιστεί στην εφαρμογή

function needUser(req) {
  if (!req.auth || !req.auth.uid) throw new HttpsError("unauthenticated", "Χρειάζεται σύνδεση");
  return req.auth;
}
const isAdmin = a => !!a && a.token && a.token.email === ADMIN_EMAIL && a.token.email_verified === true;

let _pub = null;
async function publisher() {
  if (_pub) return _pub;
  const { google } = require("googleapis");
  const auth = new google.auth.GoogleAuth({ scopes: ["https://www.googleapis.com/auth/androidpublisher"] });
  _pub = google.androidpublisher({ version: "v3", auth });
  return _pub;
}

async function proConfig() {
  const c = await db.doc("config/pro").get();
  const d = c.exists ? c.data() || {} : {};
  return { foundingUntil: d.foundingUntil || FOUNDING_DEFAULT, grants: Array.isArray(d.grants) ? d.grants : [] };
}
// Υπολογίζει και αποθηκεύει Founding / δώρο για έναν χρήστη
async function syncUser(uid, user, cfg) {
  user = user || await admin.auth().getUser(uid);
  cfg = cfg || await proConfig();
  const founding = L.isFounding(user.metadata && user.metadata.creationTime, cfg.foundingUntil);
  const granted = L.isGranted(user.email, user.emailVerified, cfg.grants);
  const ref = db.doc(`pro/${uid}`);
  await ref.set({ founding, granted, synced: FV.serverTimestamp() }, { merge: true });
  return (await ref.get()).data() || {};
}
function status(d) {
  const now = Date.now();
  return { kind: L.proKind(d, now), pro: L.isPro(d, now), purchased: d.purchased === true, founding: d.founding === true, granted: d.granted === true,
    trialStart: L.tsMs(d.trialStart) || null, trialEnd: L.tsMs(d.trialEnd) || null };
}
async function userIsPro(auth) {
  if (isAdmin(auth)) return true;
  const p = await db.doc(`pro/${auth.uid}`).get();
  return L.isPro(p.exists ? p.data() : null, Date.now());
}

/* ---------- Pro ---------- */
exports.proSync = onCall(CALL, async req => {
  const a = needUser(req);
  const d = await syncUser(a.uid);
  return status(d);
});

exports.proTrial = onCall(CALL, async req => {
  const a = needUser(req);
  const used = db.doc(`trialUsed/${a.uid}`), ref = db.doc(`pro/${a.uid}`);
  const out = await db.runTransaction(async tx => {
    const [u, p] = await Promise.all([tx.get(used), tx.get(ref)]);
    if (u.exists || (p.exists && p.data().trialStart)) return null;
    const now = Date.now();
    tx.set(used, { at: FV.serverTimestamp() });
    tx.set(ref, { trialStart: TS.fromMillis(now), trialEnd: TS.fromMillis(now + L.TRIAL_DAYS * 864e5) }, { merge: true });
    return true;
  });
  if (!out) throw new HttpsError("already-exists", "Η δωρεάν δοκιμή έχει ήδη χρησιμοποιηθεί");
  return status((await ref.get()).data());
});

exports.proVerify = onCall(CALL, async req => {
  const a = needUser(req);
  const token = String((req.data && req.data.token) || "");
  if (token.length < 20 || token.length > 600 || !/^[A-Za-z0-9._\-:]+$/.test(token)) throw new HttpsError("invalid-argument", "Μη έγκυρη αγορά");
  const h = L.sha256(token);
  const claim = db.doc(`purchases/${h}`);
  const c = await claim.get();
  if (c.exists && c.data().uid !== a.uid) throw new HttpsError("permission-denied", "Η αγορά ανήκει σε άλλον λογαριασμό");
  let p;
  try {
    const api = await publisher();
    p = (await api.purchases.products.get({ packageName: PKG, productId: PRODUCT, token })).data;
  } catch (e) {
    logger.warn("proVerify: Play API", e && e.code, e && e.message);
    throw new HttpsError(e && (e.code === 400 || e.code === 404 || e.code === 410) ? "not-found" : "unavailable", "Η αγορά δεν επιβεβαιώθηκε");
  }
  const r = L.checkPurchase(p, a.uid);
  if (!r.ok) throw new HttpsError("failed-precondition", "Η αγορά δεν είναι ενεργή (" + r.why + ")");
  const ref = db.doc(`pro/${a.uid}`);
  await db.runTransaction(async tx => {
    const cc = await tx.get(claim);
    if (cc.exists && cc.data().uid !== a.uid) throw new HttpsError("permission-denied", "Η αγορά ανήκει σε άλλον λογαριασμό");
    if (!cc.exists) tx.set(claim, { uid: a.uid, orderId: String(p.orderId || "").slice(0, 120), test: r.test, at: FV.serverTimestamp() });
    tx.set(ref, { purchased: true, orderId: String(p.orderId || "").slice(0, 120), purchasedAt: FV.serverTimestamp(), test: r.test, voided: false }, { merge: true });
  });
  if (!r.ack) {
    try { const api = await publisher(); await api.purchases.products.acknowledge({ packageName: PKG, productId: PRODUCT, token, requestBody: {} }); }
    catch (e) { logger.warn("proVerify: acknowledge", e && e.message); }
  }
  return status((await ref.get()).data());
});

// Ακυρωμένες αγορές / επιστροφές χρημάτων: αφαιρείται το Pro
exports.proVoided = onSchedule({ schedule: "every 12 hours", timeZone: "Europe/Athens" }, async () => {
  const api = await publisher();
  const st = db.doc("sys/voided"); const s = await st.get();
  const since = s.exists ? s.data().t : Date.now() - 29 * 864e5;
  const now = Date.now(); let pageToken, n = 0;
  do {
    const r = (await api.purchases.voidedpurchases.list({ packageName: PKG, startTime: String(since), endTime: String(now), maxResults: 1000, token: pageToken })).data;
    for (const v of r.voidedPurchases || []) {
      if (!v.purchaseToken) continue;
      const c = await db.doc(`purchases/${L.sha256(v.purchaseToken)}`).get();
      if (!c.exists) continue;
      await db.doc(`pro/${c.data().uid}`).set({ purchased: false, voided: true, voidedAt: FV.serverTimestamp() }, { merge: true });
      n++;
    }
    pageToken = r.tokenPagination && r.tokenPagination.nextPageToken;
  } while (pageToken);
  await st.set({ t: now });
  logger.info("proVoided", n);
});

// Founding / δώρα για όλους (μία φορά τη μέρα και όποτε το ζητήσει ο admin)
async function backfill() {
  const cfg = await proConfig(); let next, n = 0;
  do {
    const r = await admin.auth().listUsers(1000, next);
    for (const u of r.users) { await syncUser(u.uid, u, cfg); n++; }
    next = r.pageToken;
  } while (next);
  return n;
}
exports.proBackfill = onCall(CALL, async req => {
  const a = needUser(req); if (!isAdmin(a)) throw new HttpsError("permission-denied", "Μόνο για τον διαχειριστή");
  return { users: await backfill() };
});
exports.proDaily = onSchedule({ schedule: "every day 04:10", timeZone: "Europe/Athens" }, async () => { logger.info("proDaily", await backfill()); });

/* ---------- Παρέα ---------- */
async function crewGate(a) {
  if (isAdmin(a)) return;
  const c = await db.doc("config/crew").get();
  if (!(c.exists && c.data().open === true)) throw new HttpsError("permission-denied", "Η Παρέα έρχεται σύντομα");
}
async function myGroups(uid) {
  const r = await db.collection("groups").where("members", "array-contains", uid).count().get();
  return r.data().count;
}
async function checkLimit(a) {
  const [n, pro] = await Promise.all([myGroups(a.uid), userIsPro(a)]);
  if (n >= L.groupLimit(pro)) throw new HttpsError("resource-exhausted", pro ? "limit-pro" : "limit");
}

exports.crewCreate = onCall(CALL, async req => {
  const a = needUser(req); await crewGate(a);
  const name = L.cleanName(req.data && req.data.name);
  if (!name) throw new HttpsError("invalid-argument", "Γράψε όνομα 2–30 χαρακτήρων");
  if (!(await db.doc(`profiles/${a.uid}`).get()).exists) throw new HttpsError("failed-precondition", "Φτιάξε πρώτα το προφίλ σου στην Παρέα");
  await checkLimit(a);
  const gRef = db.collection("groups").doc();
  for (let k = 0; k < 6; k++) {
    const code = L.genCode(), cRef = db.doc(`codes/${code}`);
    const ok = await db.runTransaction(async tx => {
      if ((await tx.get(cRef)).exists) return false;
      tx.create(gRef, { name, code, owner: a.uid, members: [a.uid], banned: [], created: FV.serverTimestamp() });
      tx.create(cRef, { gid: gRef.id });
      return true;
    });
    if (ok) return { gid: gRef.id, code };
  }
  throw new HttpsError("unavailable", "Δοκίμασε ξανά");
});

exports.crewJoin = onCall(CALL, async req => {
  const a = needUser(req); await crewGate(a);
  const code = L.normCode(req.data && req.data.code);
  if (!code) throw new HttpsError("invalid-argument", "Ο κωδικός έχει 6 γράμματα ή αριθμούς");
  if (!(await db.doc(`profiles/${a.uid}`).get()).exists) throw new HttpsError("failed-precondition", "Φτιάξε πρώτα το προφίλ σου στην Παρέα");
  const c = await db.doc(`codes/${code}`).get();
  if (!c.exists) throw new HttpsError("not-found", "Δεν βρέθηκε παρέα με αυτόν τον κωδικό");
  const gid = c.data().gid, gRef = db.doc(`groups/${gid}`);
  const g0 = await gRef.get();
  if (!g0.exists) throw new HttpsError("not-found", "Δεν βρέθηκε παρέα με αυτόν τον κωδικό");
  if ((g0.data().members || []).includes(a.uid)) return { gid, already: true };
  await checkLimit(a);
  await db.runTransaction(async tx => {
    const g = await tx.get(gRef); if (!g.exists) throw new HttpsError("not-found", "Η παρέα δεν υπάρχει πια");
    const d = g.data();
    if ((d.banned || []).includes(a.uid)) throw new HttpsError("permission-denied", "Δεν μπορείς να μπεις σε αυτή την παρέα");
    if ((d.members || []).length >= L.CREW_MAX) throw new HttpsError("resource-exhausted", "full");
    tx.update(gRef, { members: FV.arrayUnion(a.uid) });
  });
  return { gid };
});
