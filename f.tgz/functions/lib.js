"use strict";
// Καθαρή λογική (χωρίς Firebase), για να ελέγχεται με απλά tests.
const crypto = require("crypto");

const TRIAL_DAYS = 3;
const CREW_MAX = 50;          // μέλη ανά παρέα
const FREE_GROUPS = 1;        // παρέες για μη Pro
const PRO_GROUPS = 20;        // ανώτατο όριο για Pro (κατά της κατάχρησης)
const CODE_ABC = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

const sha256 = s => crypto.createHash("sha256").update(String(s)).digest("hex");
// Αναγνωριστικό λογαριασμού για το Google Play (obfuscatedAccountId): δεν αποκαλύπτει το uid
const uidHash = uid => sha256("ridemind:" + uid).slice(0, 64);

const tsMs = t => !t ? 0 : typeof t.toMillis === "function" ? t.toMillis() : typeof t === "number" ? t : (t._seconds ? t._seconds * 1000 : 0);

// Pro: αγορά, Founding Rider, δώρο ή ενεργή δοκιμή
function proKind(d, now) {
  d = d || {};
  if (d.purchased === true) return "owned";
  if (d.founding === true) return "founding";
  if (d.granted === true) return "granted";
  if (tsMs(d.trialEnd) > now) return "trial";
  return "free";
}
const isPro = (d, now) => proKind(d, now) !== "free";

// Founding Rider: λογαριασμός που φτιάχτηκε έως και την ημερομηνία (Ελλάδα, τέλος ημέρας)
function isFounding(creationTime, foundingUntil) {
  const c = Date.parse(creationTime || ""); if (!c) return false;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(foundingUntil || "")); if (!m) return false;
  const lim = Date.UTC(+m[1], +m[2] - 1, +m[3], 23, 59, 59) - 2 * 3600e3; // ώρα Ελλάδας (UTC+2)
  return c <= lim;
}
function isGranted(email, emailVerified, grants) {
  if (!email || emailVerified !== true || !Array.isArray(grants)) return false;
  const e = String(email).toLowerCase().trim();
  return grants.some(g => String(g).toLowerCase().trim() === e);
}

// Όνομα παρέας: 2–30 χαρακτήρες, χωρίς χαρακτήρες ελέγχου
function cleanName(s) {
  const n = String(s == null ? "" : s).replace(/[\u0000-\u001f\u007f​-‏‪-‮]/g, "").replace(/\s+/g, " ").trim();
  return n.length >= 2 && n.length <= 30 ? n : null;
}
function normCode(s) {
  const c = String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return c.length === 6 ? c.slice(0, 3) + "-" + c.slice(3) : null;
}
function genCode(rand = crypto.randomBytes) {
  const r = rand(6); let s = "";
  for (let i = 0; i < 6; i++) { s += CODE_ABC[r[i] % CODE_ABC.length]; if (i === 2) s += "-"; }
  return s;
}
// Πόσες παρέες επιτρέπονται
const groupLimit = pro => pro ? PRO_GROUPS : FREE_GROUPS;

// Έλεγχος αγοράς από την απάντηση του Google Play (purchases.products.get)
function checkPurchase(p, uid) {
  if (!p) return { ok: false, why: "missing" };
  if (p.purchaseState !== 0) return { ok: false, why: "state" }; // 0 = αγοράστηκε, 1 = ακυρώθηκε, 2 = εκκρεμεί
  if (p.obfuscatedExternalAccountId && p.obfuscatedExternalAccountId !== uidHash(uid)) return { ok: false, why: "account" };
  if (p.purchaseType === 0) return { ok: true, test: true, ack: p.acknowledgementState === 1 }; // αγορά δοκιμής (license tester)
  return { ok: true, test: false, ack: p.acknowledgementState === 1 };
}

module.exports = { TRIAL_DAYS, CREW_MAX, FREE_GROUPS, PRO_GROUPS, sha256, uidHash, tsMs, proKind, isPro, isFounding, isGranted, cleanName, normCode, genCode, groupLimit, checkPurchase };
